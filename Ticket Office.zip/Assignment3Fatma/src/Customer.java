public class Customer implements Comparable <Customer>, Ratable
{
    private int ID;
    private String name;
    private int age;
    private char gender;
    private int registeredBy;
    private int numOfTickets;
    private double ordersPrice;

    public Customer(int ID, String name, int age, char gender, int registeredBy) throws WrongGenderException
    {//constructor
        this.ID=ID;
        this.name=name;
        this.age=age;
        this.registeredBy=registeredBy;
        if(gender!='f' && gender!='m')
            throw new WrongGenderException();
        this.gender=gender;
        this.numOfTickets=0;
        this.ordersPrice =0;
    }

    public int getID()
    {
        return this.ID;
    }

    public String getName()
    {
        return this.name;
    }

    public int getAge()
    {
        return this.age;
    }

    public char getGender()
    {
        return this.gender;
    }

    public int getRegisteredBy()
    {
        return registeredBy;
    }

    public int getNumOfTickets()
    {
        return this.numOfTickets;
    }

    @Override
    public double getRate()
    {
        return this.ordersPrice;
    }

    public void updateNumOfTickets(int num)
    {
        this.numOfTickets+=num;
    }

    public void updateOrdersPrice(double price)
    {
        this.ordersPrice +=price;
    }

    public String toString()
    {
        return "Name: " + this.name + "; age: "+ this.age +"; Gender: "+ this.gender;
    }

    @Override
    public int compareTo(Customer o)
    {//compares by the amount of tickets bought by the customers
        return this.getNumOfTickets()-o.getNumOfTickets();
    }
}
