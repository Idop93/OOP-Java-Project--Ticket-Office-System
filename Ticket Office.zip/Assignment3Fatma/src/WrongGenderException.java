import java.io.IOException;
public class WrongGenderException extends IOException
{
    private String Message;

    public WrongGenderException()
    {
        Message = "Illegal gender, can't create customer";
    }

    public String getMessage()
    {
        return Message;
    }

}

