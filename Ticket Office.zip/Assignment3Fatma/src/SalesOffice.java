import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.Vector;
import java.io.BufferedReader;
import java.io.FileReader;

public class SalesOffice
{
    public Vector <Event> EventsV;
    public Vector <Employee> EmployeesV;
    public Vector <Customer> CustomersV;
    public Vector <Order> OrdersV;

    public SalesOffice(String fileEvents, String fileEmployees, String fileCustomers , String fileTicketsSales)
    {//constructor
        EventsV= new Vector<Event>();
        EmployeesV= new Vector<Employee>();
        CustomersV= new Vector<Customer>();
        OrdersV= new Vector<Order>();
        ReadFile(fileEvents,"Events");
        ReadFile(fileEmployees,"Employees");
        ReadFile(fileCustomers,"Customers");
        ReadFile(fileTicketsSales,"Orders");
    }

    public void ReadFile(String FileName , String objectType)
    {
        BufferedReader inFile = null;
        try {
                FileReader fr = new FileReader(FileName);
                inFile = new BufferedReader(fr);
                String line=inFile.readLine();//intiates on the first line but doesn't use it
                while((line=inFile.readLine()) != null)//in first entrance to while loop continues to next line
                {//runs till the end of the file
                    String [] lineSplit = line.split("\\t");
                    switch(objectType)
                    {
                        case "Orders":
                        {
                            createOrderFromArr(lineSplit);
                            break; // case Orders
                        }
                        case "Events":
                        {
                            createEventFromArr(lineSplit);
                            break; // case Events
                        }
                        case "Customers":
                        {
                            createCusFromArr(lineSplit);
                            break; // case Customers
                        }
                        case "Employees":
                        {
                            createEmpFromArr(lineSplit);
                            break; // case Employee
                        }
                    }//switch
                }//while
            }//try
        catch(FileNotFoundException exception)
        {
            System.out.println("The file" + FileName + "was not found.");
        }//catch1
        catch(IOException exception)
        {
            System.out.println(exception);
        }//catch 2
        finally
        {
            try
            {
                inFile.close();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }//read file

    public void createOrderFromArr(String [] arr)
    {//creates a new element in the Orders Vector
        boolean isOffline=false;
        if(arr.length==5)
        {//if there is a url the length is 5 and not 4
            OrdersV.add(new OnlineOrder(Integer.parseInt(arr[0]), Integer.parseInt(arr[1]),
                    Integer.parseInt(arr[3]), arr[4]));
        }
        else
        {
            OrdersV.add(new OfflineOrder(Integer.parseInt(arr[0]), Integer.parseInt(arr[1]),
                    Integer.parseInt(arr[2]), Integer.parseInt(arr[3])));
            isOffline=true;
        }
        updateOrderInfo(isOffline);
    }

    private void updateOrderInfo(boolean isOffline)
    {//updates fields of the customer & the employees who are relevant to this order
        Order order = this.OrdersV.elementAt(this.OrdersV.size()-1);
        Event event = getEventByID(order.getEventID());
        Customer customer = getCusByID(order.getSoldTo());
        double sumPrice = calcOrderPrice(event);
        updateEvent(order, event);
        order.updatePrice(sumPrice);//updates order's price field
        if(customer!=null)
        {
            updateCustomer(order, customer, sumPrice);
            updateEmployee(order, customer, sumPrice, isOffline);
        }
    }

    private void updateCustomer(Order order, Customer customer, double sumPrice)
    {//updates customer's fields - numOfTickets & orderPrice
        customer.updateNumOfTickets(order.getNumOfTickets());
        customer.updateOrdersPrice(sumPrice);
    }

    private void updateEmployee(Order order, Customer customer, double sumPrice, boolean isOffline)
    {//updates employee's salaries
        if(isOffline)
        {//order is offline then a marketing employee receives a bonus for it
            Employee employee = getEmpByID(((OfflineOrder)order).getSoldBy());
            employee.updateSalary(sumPrice);
        }
        Employee employee = getEmpByID(customer.getRegisteredBy());//employee who registered the customer get a bonus
        employee.updateSalary(sumPrice);
    }

    private void updateEvent(Order order, Event event)
    {//updates event's field numOfTickets with the number purchased in this order
        if(event!=null)
            event.updateNumOfTickets(order.getNumOfTickets());
    }

    private Customer getCusByID(int id)
    {//returns a customer with the given id
        for(Customer cus : CustomersV)
        {
            if(cus.getID()==id)
                return cus;
        }
        return null;
    }

    private Event getEventByID(int id)
    {//returns an event with the given id
        for(Event eve : EventsV)
        {
            if(eve.getID()==id)
                return eve;
        }
        return null;
    }

    private Employee getEmpByID(int id)
    {//returns an employee with the given id
        for(Employee emp : EmployeesV)
        {
            if(emp.getID()==id)
                return emp;
        }
        return null;
    }

    private int getCustomerAge(int id)
    {//returns a customer's age with the given id
        for(Customer cus : CustomersV)
        {
            if(cus.getID()==id)
                return cus.getAge();
        }
        return 0;
    }

    private double calcOrderPrice(Event eve)
    {//returns the total price of the order
        if(eve!=null)
        {
            return getAmountTicketsPerOrder(eve.getID()) * eve.getPrice();
        }
        return 0;
    }

    public int getAmountTicketsPerOrder(int eventId)
    {//returns the total amount of tickets sold to this event
        for(Order order : OrdersV)
        {
            if(eventId==order.getEventID())
                return order.getNumOfTickets();
        }
        return 0;
    }

    public void createEventFromArr(String [] arr)
    {//creates a new element in the Events Vector
        try
        {
            EventsV.add(new Event(arr[0], Integer.parseInt(arr[1]), Integer.parseInt(arr[2])));
        }
        catch(NegativePriceException e)//exception for a negative price of an event
        {
            System.err.println("Negative price exception");
        }
    }

    public void createCusFromArr(String [] arr)
    {//creates a new element in the Customers Vector
        try
        {
            Customer cus = new  Customer(Integer.parseInt(arr[0]), arr[1], Integer.parseInt(arr[2]),
                    arr[3].charAt(0), Integer.parseInt(arr[4]));
            CustomersV.add(cus);
            MarketingEmployee marketingEmp = (MarketingEmployee) getEmpByID(cus.getRegisteredBy());
            marketingEmp.updateCustomerCounter();//update his registered customers counter for bonus
        }
        catch(WrongGenderException e)//exception for an illegal gender
        {
            System.err.println(e.getMessage());
        }
    }

    public void createEmpFromArr(String [] arr)
    {//creates a new element in the Employees Vector
        if(arr.length==5)
        {//if there is a phone number the length is 5
            this.EmployeesV.add(new MarketingEmployee(Integer.parseInt(arr[0]), arr[1], Integer.parseInt(arr[2]),
                    arr[4]));
        }
        else
        {
            this.EmployeesV.add(new SalesEmployee(Integer.parseInt(arr[0]), arr[1], Integer.parseInt(arr[2]),
                    Double.parseDouble(arr[3])));
        }
    }

    public void printAgeReport(int eventID)
    {//prints the age report of the customers attending this event
        System.out.println("Event name: "+ getEventName(eventID));
        double [] ageArray = getAgeArray(eventID);//help array in which every index is an age group
        printAmounts(getTotalAmount(ageArray), ageArray);//prints the amount of users in each age group
    }

    public String getEventName(int eventID)
    {
        for(Event event : EventsV)
        {
            if(event.getID()==eventID)
                return event.getName();
        }
        return "";
    }

    public double [] getAgeArray(int eventID)
    {//returns the amount of customers of each age group in a help array
        double [] ageArray = new double [6];
        for(Order order : OrdersV)
        {
            if(order.getEventID()==eventID)
            {
                int currentID = order.getSoldTo();
                for(Customer customer : CustomersV)
                {
                    int currentAge;
                    if(customer.getID()==currentID)
                    {//if the customer's id is the "soldTo" customer then add his age to the help array
                        currentAge = customer.getAge();
                        ageArray=updateAgeReport(currentAge, ageArray);
                        break;
                    }
                }
            }
        }
        return ageArray;
    }

    public double[] updateAgeReport(int currentAge, double [] arr)
    {//updates the help array
        if(currentAge<18)
            arr[0]++;
        else if(currentAge>18 && currentAge<=24)
            arr[1]++;
        else if(currentAge>24 && currentAge<=35)
            arr[2]++;
        else if(currentAge>35 && currentAge<=50)
            arr[3]++;
        else if(currentAge>50 && currentAge<=70)
            arr[4]++;
        else
            arr[5]++;
        return arr;
    }

    public void printAmounts(double counter, double [] ageArray)
    {//prints the amount of users in each age group
        for(int i=0; i<ageArray.length; i++)
        {
            switch(i)
            {
                case(0):
                    System.out.println("0-18: "+ (int)(((ageArray[0])/counter)*100) +"%");
                    break;
                case(1):
                    System.out.println("18-24: "+ (int)(((ageArray[1])/counter)*100) +"%");
                    break;
                case(2):
                    System.out.println("25-35: "+ (int)(((ageArray[2])/counter)*100) +"%");
                    break;
                case(3):
                    System.out.println("36-50: "+ (int)(((ageArray[3])/counter)*100) +"%");
                    break;
                case(4):
                    System.out.println("51-70: "+ (int)(((ageArray[4])/counter)*100) +"%");
                    break;
                case(5):
                    System.out.println("71+: "+(int) (((ageArray[5])/counter)*100) +"%");
                    break;
            }
        }
    }

    public double getTotalAmount(double [] ageArray)
    {//count the total amount of customers going the event
        double counterTotal=0;
        for(int i=0; i<ageArray.length; i++)
        {
            counterTotal+=ageArray[i];
        }
        return counterTotal;
    }

    public double getOnlineProportion()
    {//returns the amount of online orders made out of all orders made in the sales office
        double counterT=OrdersV.size();//amount of orders
        double counterO=0;//amount of online orders
        for (Order order : OrdersV)
        {
            if(order instanceof OnlineOrder)
                counterO++;
        }
        return (counterO/counterT);
    }

    public double getBalance()
    {//returns the balance of the sales office
        return getIncome()-getExpense();
    }

    public double getIncome()
    {//returns sum of all incomes from all orders made in the sales office
        double income=0;
        double currentPrice=0;
        int currentID;
        for(Order order : OrdersV)
        {
            currentID=order.getEventID();
            for (Event event : EventsV)
            {
                if(event.getID()==currentID)
                {
                    currentPrice = event.getPrice();
                    income += order.getNumOfTickets() * currentPrice;//adds the total order price to income
                    break;
                }
            }
        }
        return income;
    }

    public double getExpense()
    {//returns the sum of all salaries paid to all employees of the sales office
        double ans=0;
        for(Employee emp : EmployeesV)
        {
            ans += emp.getRate();
        }
        return ans;
    }

    public void firmReport()
    {//prints a report of sales office details
        System.out.println("SalesOffice report:");
        printEmpReport();
        printEventsReport();
        printCusReport();
    }

    public void printEmpReport()
    {//creates and prints the details of sales office employees
        System.out.println("Employees list:");
        Collections.sort(EmployeesV);//creates the collection in ascending order and sorts by compareTo implementation
        Collections.reverse(EmployeesV);//reverses the collection to descending order
        for(Employee employee : EmployeesV)
        {
            System.out.println(employee);
        }
    }

    public void printEventsReport()
    {//creates and prints the details of sales office events
        System.out.println("- - - - - - - - - - - - - - -");
        System.out.println("Event list:");
        Collections.sort(EventsV);//creates the collection in ascending order and sorts by compareTo implementation
        Collections.reverse(EventsV);//reverses the collection to descending order
        for(Event event : EventsV)
        {
            System.out.println(event);
        }
    }

    public void printCusReport()
    {//creates and prints the details of sales office customers
        System.out.println("- - - - - - - - - - - - - - -");
        System.out.println("Customer list:");
        Collections.sort(CustomersV);//creates the collection in ascending order and sorts by compareTo implementation
        Collections.reverse(CustomersV);//reverses the collection to descending order
        for(Customer customer : CustomersV)
        {
            System.out.println(customer);
        }
    }

    public Comparable <?> getMax(Vector <? extends Comparable> v)
    {//returns the max element in Comparable vector based on compareTo implementation
        Comparable <?> ans = v.elementAt(0);
        for(Comparable object : v)
        {
            if(object.compareTo(ans)>0)
                ans = object;
        }
        return ans;
    }

    public static double getAvgValue(Vector <? extends Ratable> v)
    {//returns the average of all elements in Ratable vector based on getRate implementation
        double counter=0;
        double ans = 0;
        for(Ratable object : v)
        {
            counter++;
            ans += object.getRate();
        }
        return (ans/counter);
    }

    public void printAvg()
    {//todo lehaif
        System.out.println(getAvgValue(EmployeesV));
        System.out.println(getAvgValue(CustomersV));
        System.out.println(getAvgValue(EventsV));
        System.out.println(getAvgValue(OrdersV));
    }

    public static void main(String [] args)
    {//todo taif
        String fEvents=new String("C:\\Users\\shayp\\eclipse-workspace\\Assignment3Fatma\\data\\Events.txt");
        String fEmployees=new String("C:\\Users\\shayp\\eclipse-workspace\\Assignment3Fatma\\data\\Employees.txt");
        String fCustomers=new String("C:\\Users\\shayp\\eclipse-workspace\\Assignment3Fatma\\data\\Customers.txt");
        String fTickets=new String("C:\\Users\\shayp\\eclipse-workspace\\Assignment3Fatma\\data\\Orders.txt");
        SalesOffice s = new SalesOffice(fEvents,  fEmployees,  fCustomers ,  fTickets);
        s.firmReport();
    }
}