public class OnlineOrder extends Order
{
    public String URL;

    public OnlineOrder(int eventID,	int soldTo, int	numberOfTickets, String URL)
    {//constructor
        super(eventID, soldTo, numberOfTickets);
        this.URL = URL;
    }
}
