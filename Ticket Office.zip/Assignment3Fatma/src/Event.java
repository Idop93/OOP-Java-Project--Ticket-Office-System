import java.util.Vector;

public class Event implements Comparable <Event>, Ratable
{
    private String name;
    private int ID;
    private int price;
    private int numOfTickets;

    public Event(String name, int serialNum, int price) throws NegativePriceException
    {//constructor
        if(price<0)
            throw new NegativePriceException();
        this.ID =serialNum;
        this.name=name;
        this.price=price;
        this.numOfTickets=0;
    }

    public String getName()
    {
        return this.name;
    }

    public int getID()
    {
        return this.ID;
    }

    public int getPrice()
    {
        return this.price;
    }

    public int getNumOfTickets()
    {
        return this.numOfTickets;
    }

    public void updateNumOfTickets(int num)
    {
        this.numOfTickets+=num;
    }

    @Override
    public double getRate()
    {
        return this.price;
    }

    @Override
    public int compareTo(Event o)
    {//compares by the amount of tickets sold to the event
        return this.getNumOfTickets()-o.getNumOfTickets();
    }

    public String toString()
    {
        return this.name;
    }

}
