import java.util.Vector;

abstract class Employee implements Comparable <Employee>, Ratable
{
    protected int ID;
    protected String name;
    protected int age;
    protected double salary;
    protected double bonus;

    public Employee(int ID, String name, int age)
    {//constructor
        this.ID=ID;
        this.name=name;
        this.age=age;
        this.salary=0;
    }

    public int getID()
    {
        return this.ID;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getRate()
    {
        return this.salary;
    }

    public void updateSalary(double price)
    {
        this.salary += price*this.bonus;
    }

    @Override
    public int compareTo(Employee other)
    {//compares by the salary of the employee
        return (int) (this.salary - other.salary);
    }

    public String toString()
    {
        return ("Name: " + this.name + "; age: " + this.age);
    }

}