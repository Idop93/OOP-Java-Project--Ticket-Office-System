public class Order implements Comparable <Order>, Ratable
{
    protected int eventID;
    protected int soldTo;
    protected int numOfTickets;
    protected double price;

    public Order(int eventID, int soldTo, int numberOfTickets)
    {//constructor
        this.eventID=eventID;
        this.soldTo=soldTo;
        this.numOfTickets =numberOfTickets;
        this.price=0;
    }

    public int getEventID()
    {
        return this.eventID;
    }

    public int getSoldTo()
    {
        return this.soldTo;
    }

    public int getNumOfTickets()
    {
        return this.numOfTickets;
    }

    public void updatePrice(double price)
    {
        this.price=price;
    }

    @Override
    public double getRate()
    {
        return this.price;
    }

    @Override
    public int compareTo(Order other)
    {//compares by the amount of tickets bought in the order
        return this.numOfTickets - other.numOfTickets;
    }

}