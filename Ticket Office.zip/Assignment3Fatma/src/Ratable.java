public interface Ratable
{
    public double getRate();
}
