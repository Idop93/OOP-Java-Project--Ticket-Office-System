import java.util.Vector;

public class MarketingEmployee extends Employee
{
    private String phone;

    public MarketingEmployee(int ID, String name, int age, String phone)
    {//constructor
        super(ID, name, age);
        this.phone=phone;
        this.bonus=0.01;
    }

    public void updateCustomerCounter()
    {
        this.salary+=2;
    }

}
