import java.util.Vector;

public class SalesEmployee extends Employee
{

    public SalesEmployee(int ID, String name, int age, double bonus)
    {//constructor
        super(ID, name, age);
        this.bonus = bonus;
    }

}
