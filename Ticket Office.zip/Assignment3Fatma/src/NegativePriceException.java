import java.io.IOException;

public class NegativePriceException extends IOException
{//if gender is different than 'f' & 'm'

    private String Message;

    public NegativePriceException()
    {
        System.err.println("No gender stated, can't create customer");
    }

    public String getMessage()
    {
        return Message;
    }

}
