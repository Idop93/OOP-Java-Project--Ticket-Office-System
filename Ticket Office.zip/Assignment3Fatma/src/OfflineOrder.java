public class OfflineOrder extends Order
{

    private int soldBy;

    public OfflineOrder(int eventID, int soldTo, int soldBy, int numberOfTickets)
    {//constructor
        super(eventID, soldTo, numberOfTickets);
        this.soldBy = soldBy;
    }

    public int getSoldBy()
    {
        return soldBy;
    }
}
